#ask the user to write a quote and the print it to the consol.
quote = input("Hi, write some text for me to steal! Write here:")
print ('"' + quote +'"')