#user input
input_numbers = str(input("Pleace provide me with three digits. Enter here:"))

#assigne each number to a veriable
number0 = input_numbers[0]
number1 = input_numbers[1]
number2 = input_numbers[2]

#want to calculate the numbers togheter and print the outcome
sum = int(number0) + int(number1) + int(number2) 
print(sum)
