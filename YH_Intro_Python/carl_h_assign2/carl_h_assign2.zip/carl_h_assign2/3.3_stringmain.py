#our functions
from stringfunctions import *

#hard core code variabels
s = "hello"
n = 3
x = "l"
XXX = "XXYYYY"
duplicates ="Greetings"


#print our results 
print("Concat:",concat (s,n))
print("Count:",count (s,x))
print("Reverse:",reverse (s))
print("Two XX:",has_two_X (XXX))
print("Duplicates:",has_duplicates (duplicates))



